NMake Makefiles JOM
-------------------

Generates JOM makefiles.

.. versionadded:: 3.8
  :generator:`CodeBlocks` generator can be used as an extra generator.
